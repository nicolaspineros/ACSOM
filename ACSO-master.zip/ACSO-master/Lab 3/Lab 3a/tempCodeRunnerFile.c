        // for (i = 0; i < SIZE; i++){
        //     printf("%d ", binEntero[i]);
        // }

        // printf("%c", '\n');
        // for (i = 0; i < SIZE; i++){
        //     printf("%d ", binReal[i]);
        // }
	    // printf("%c", '\n');   